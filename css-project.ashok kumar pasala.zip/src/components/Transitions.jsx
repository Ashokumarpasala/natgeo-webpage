import React from 'react'

function Transitions() {
  return (
      
      <div className=' p-5 trans' style={{backgroundColor:"black"}}>
        <div className="container-xl ">
        <div class="row">
    <div class="col-8">        <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
</div>
    <div class="col-4">
    <div className='d-flex'>
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         {/* <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" /> */}

         </div>
    </div>
  </div>
            {/* <div className="d-flex">

        <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <div className='d-flex flex-wrap'>
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />
         <img className='card rounded-4'  src="https://varmentguard.com/uploads/permanent/963dbe2472d23882bf65f6fc5748ffbe.jpg" alt="" />

         </div> */}
            </div>
        </div>
  )
}

export default Transitions
