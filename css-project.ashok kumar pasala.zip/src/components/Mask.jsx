import React from 'react'

function Mask() {
  return (
    <div>
      mask
    </div>
  )
}

export default Mask
